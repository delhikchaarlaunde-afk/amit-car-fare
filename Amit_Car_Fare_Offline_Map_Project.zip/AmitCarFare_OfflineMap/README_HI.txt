AMIT CAR FARE - Offline Maps Android Project (v1.1)

Features:
- Offline fare calculator: One Way / Round Trip
- KM rate, Toll, Parking, Night, Waiting, Driver allowance, Other, Advance
- WhatsApp bill sharing
- Offline vector map viewer using Mapsforge .map files
- Map file is copied into app-private storage and remains available offline

IMPORTANT MAP DATA NOTE:
The ZIP does NOT contain the actual UP/Delhi/Haryana/Rajasthan map data. The app needs
a Mapsforge-compatible .map file covering the North India region (or a suitable
regional map). You must obtain/download that map file separately while online,
then import it from the Offline Map screen. Once imported, map display works offline.
A normal .osm or .pbf file is not directly supported by this viewer.

Build:
1. Extract ZIP on a computer.
2. Open folder in Android Studio.
3. Wait for Gradle Sync (internet needed once to download libraries).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK path: app/build/outputs/apk/debug/app-debug.apk

Map library: Mapsforge 0.25.0. It is an open-source offline vector map renderer.
OpenStreetMap attribution should be retained in app distribution.
